ui = input("Type a string: ")
first = int(input("First index: "))
sec = int(input("Second index: "))
print(ui[first:sec])


