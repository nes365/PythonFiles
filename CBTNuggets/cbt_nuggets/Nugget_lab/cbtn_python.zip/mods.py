def square(x):
    return x * x

if __name__ == '__main__':
    print('Testing: square of 2 == ', square(2))


