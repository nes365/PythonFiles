import os
import sys
def hello():
    '''This is the hello world function.'''
    print("Hello world!")
    
