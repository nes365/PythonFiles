import os

def print_cwd():
    s = os.getcwd()
    print('Your cwd is ', s)

print_cwd()
